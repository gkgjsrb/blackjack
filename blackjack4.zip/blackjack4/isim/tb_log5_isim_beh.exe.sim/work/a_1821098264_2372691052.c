/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/emha/blackjack4/tb_log5.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );


static void work_a_1821098264_2372691052_p_0(char *t0)
{
    int64 t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(231, ng0);

LAB3:    t1 = (10 * 1000LL);
    t2 = (t0 + 4232U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t4);
    t2 = (t0 + 11800);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t5;
    xsi_driver_first_trans_delta(t2, 0U, 1, t1);
    t10 = (t0 + 11800);
    xsi_driver_intertial_reject(t10, t1, t1);

LAB2:    t11 = (t0 + 11720);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1821098264_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int64 t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    int64 t18;
    char *t19;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    t1 = (t0 + 11400U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(237, ng0);
    t3 = (10 * 1000LL);
    t2 = (t0 + 11864);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_delta(t2, 0U, 1, t3);
    t8 = (20 * 1000LL);
    t9 = (t0 + 11864);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_subsequent_trans_delta(t9, 0U, 1, t8);
    t14 = (t0 + 11864);
    xsi_driver_intertial_reject(t14, t3, t3);
    xsi_set_current_line(240, ng0);
    t2 = (t0 + 11928);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(242, ng0);
    t2 = (t0 + 18727);
    t5 = (t0 + 11992);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(243, ng0);
    t2 = (t0 + 18733);
    t5 = (t0 + 12056);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(244, ng0);
    t2 = (t0 + 18739);
    t5 = (t0 + 12120);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(245, ng0);
    t2 = (t0 + 18745);
    t5 = (t0 + 12184);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(246, ng0);
    t2 = (t0 + 18751);
    t5 = (t0 + 12248);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(247, ng0);
    t2 = (t0 + 18757);
    t5 = (t0 + 12312);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(248, ng0);
    t2 = (t0 + 18763);
    t5 = (t0 + 12376);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(249, ng0);
    t2 = (t0 + 18769);
    t5 = (t0 + 12440);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(250, ng0);
    t2 = (t0 + 18775);
    t5 = (t0 + 12504);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(251, ng0);
    t2 = (t0 + 18781);
    t5 = (t0 + 12568);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(252, ng0);
    t2 = (t0 + 18787);
    t5 = (t0 + 12632);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(253, ng0);
    t2 = (t0 + 18793);
    t5 = (t0 + 12696);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(254, ng0);
    t2 = (t0 + 18799);
    t5 = (t0 + 12760);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(255, ng0);
    t2 = (t0 + 18805);
    t5 = (t0 + 12824);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(256, ng0);
    t2 = (t0 + 18811);
    t5 = (t0 + 12888);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(257, ng0);
    t2 = (t0 + 18817);
    t5 = (t0 + 12952);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(258, ng0);
    t2 = (t0 + 18823);
    t5 = (t0 + 13016);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(259, ng0);
    t2 = (t0 + 18829);
    t5 = (t0 + 13080);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(260, ng0);
    t2 = (t0 + 18835);
    t5 = (t0 + 13144);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(261, ng0);
    t2 = (t0 + 18841);
    t5 = (t0 + 13208);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(262, ng0);
    t3 = (400 * 1000LL);
    t2 = (t0 + 18847);
    t5 = (t0 + 13272);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 4U);
    xsi_driver_first_trans_delta(t5, 0U, 4U, t3);
    t8 = (500 * 1000LL);
    t11 = (t0 + 18851);
    t13 = (t0 + 13272);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t11, 4U);
    xsi_driver_subsequent_trans_delta(t13, 0U, 4U, t8);
    t18 = (600 * 1000LL);
    t19 = (t0 + 18855);
    t21 = (t0 + 13272);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t19, 4U);
    xsi_driver_subsequent_trans_delta(t21, 0U, 4U, t18);
    t26 = (t0 + 13272);
    xsi_driver_intertial_reject(t26, t3, t3);
    xsi_set_current_line(265, ng0);
    t3 = (420 * 1000LL);
    t2 = (t0 + 13336);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_delta(t2, 0U, 1, t3);
    t8 = (440 * 1000LL);
    t9 = (t0 + 13336);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_subsequent_trans_delta(t9, 0U, 1, t8);
    t14 = (t0 + 13336);
    xsi_driver_intertial_reject(t14, t3, t3);
    xsi_set_current_line(267, ng0);
    t3 = (520 * 1000LL);
    t2 = (t0 + 13400);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_delta(t2, 0U, 1, t3);
    t8 = (540 * 1000LL);
    t9 = (t0 + 13400);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_subsequent_trans_delta(t9, 0U, 1, t8);
    t14 = (t0 + 13400);
    xsi_driver_intertial_reject(t14, t3, t3);
    goto LAB2;

LAB1:    return;
}


extern void work_a_1821098264_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1821098264_2372691052_p_0,(void *)work_a_1821098264_2372691052_p_1};
	xsi_register_didat("work_a_1821098264_2372691052", "isim/tb_log5_isim_beh.exe.sim/work/a_1821098264_2372691052.didat");
	xsi_register_executes(pe);
}
